#!/bin/sh

set -e

yarn list
yarn lint
