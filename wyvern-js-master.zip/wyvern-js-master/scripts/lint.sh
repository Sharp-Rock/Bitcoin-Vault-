#!/bin/sh

yarn run tslint --project . 'src/**/*.ts' --fix
