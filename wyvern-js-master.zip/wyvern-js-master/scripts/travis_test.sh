#!/bin/sh

set -e

yarn test
